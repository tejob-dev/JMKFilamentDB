<!-- jequery plugins -->
<script src="js/jquery.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/owl.js"></script>
<script src="js/wow.js"></script>
<script src="js/validation.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/appear.js"></script>
<script src="js/scrollbar.js"></script>
<script src="js/isotope.js"></script>
<script src="js/jquery.nice-select.min.js"></script>
<script src="js/nav-tool.js"></script>
<script src="js/jquery.lettering.min.js"></script>
<script src="js/jquery.circleType.js"></script>
<script src="js/bxslider.js"></script>

<!-- main-js -->
<script src="js/script.js"></script>